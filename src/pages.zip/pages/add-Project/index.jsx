
// import React, { useEffect, useState } from 'react';
// import { useNavigate } from 'react-router-dom';
// import { getAuth, onAuthStateChanged } from 'firebase/auth';
// import { db } from '../../config/firebase-config';
// import { collection, addDoc } from 'firebase/firestore';
// import { useProjectInfo } from '../../hooks/useProjectInfo';  // Adjust the path as needed
// import logo from '../../images/logo.png';
// import './styles.css';

// export const AddProject = () => {
//     const navigate = useNavigate();
//     const auth = getAuth();
//     const [authenticated, setAuthenticated] = useState(false);

//     useEffect(() => {
//         const unsubscribe = onAuthStateChanged(auth, (user) => {
//             if (user) {
//                 setAuthenticated(true);
//             } else {
//                 navigate('/signin'); // Redirect to sign-in page if not authenticated
//             }
//         });

//         return () => unsubscribe();
//     }, [auth, navigate]);

//     const {
//         projectTitle,
//         startDate,
//         endDate,
//         location,
//         description,
//         participantQuery,
//         participants,
//         participantList,
//         imageFile,
//         imageUrl,
//         error,
//         handleInputChange,
//         handleParticipantSearch,
//         handleAddParticipant,
//         uploadImage
//     } = useProjectInfo();

//     const handleAddProject = async (e) => {
//         e.preventDefault();
//         try {
//             await uploadImage();
//             const docRef = await addDoc(collection(db, "projects"), {
//                 projectTitle,
//                 startDate,
//                 endDate,
//                 location,
//                 description,
//                 imageUrl,
//                 participants: participantList
//             });
//             console.log("Document written with ID: ", docRef.id);
//             navigate('/home');
//         } catch (error) {
//             console.error("Error adding document: ", error);
//             // setError("Error adding project. Please try again.");
//         }
//     };

//     if (!authenticated) {
//         return null; // Or a loading spinner while checking authentication
//     }

//     return (
//         <div className="container">
//             <img src={logo} alt="Logo" className="logo" />
//             <form onSubmit={handleAddProject}>
//                 <div>
//                     <label>Project Title:</label>
//                     <input type="text" name="projectTitle" value={projectTitle} onChange={handleInputChange} required />
//                 </div>
//                 <div>
//                     <label>Start Date:</label>
//                     <input type="date" name="startDate" value={startDate} onChange={handleInputChange} required />
//                 </div>
//                 <div>
//                     <label>End Date:</label>
//                     <input type="date" name="endDate" value={endDate} onChange={handleInputChange} required />
//                 </div>
//                 <div>
//                     <label>Location:</label>
//                     <input type="text" name="location" value={location} onChange={handleInputChange} required />
//                 </div>
//                 <div>
//                     <label>Description:</label>
//                     <textarea name="description" value={description} onChange={handleInputChange} required></textarea>
//                 </div>
//                 <div>
//                     <label>Project Image:</label>
//                     <input type="file" name="image" onChange={handleInputChange} />
//                 </div>
//                 <div className="participant-search">
//                     <label>Add Participant:</label>
//                     <input type="text" name="participantQuery" value={participantQuery} onChange={handleInputChange} />
//                     <button type="button" onClick={handleParticipantSearch}>Search</button>
//                 </div>
//                 {participants.length > 0 && (
//                     <ul className="participant-search-results">
//                         {participants.map(participant => (
//                             <li key={participant.id}>
//                                 {participant.name} ({participant.id})
//                                 <button type="button" onClick={() => handleAddParticipant(participant)}>Add</button>
//                             </li>
//                         ))}
//                     </ul>
//                 )}
//                 <div>
//                     <label>Participant List:</label>
//                     <ul className="participant-list">
//                         {participantList.map(id => (
//                             <li key={id}>{id}</li>
//                         ))}
//                     </ul>
//                 </div>
//                 {error && <p className="error">{error}</p>}
//                 <button type="submit">Save</button>
//             </form>
//         </div>
//     );
// };

// export default AddProject;


import React from 'react';
import { useNavigate } from 'react-router-dom';
import { db } from '../../config/firebase-config';
import { collection, addDoc } from 'firebase/firestore';
import { useProjectInfo } from '../../hooks/useProjectInfo';  // Adjust the path as needed
import logo from '../../images/logo.png';
import bird1 from '../../images/bird1.svg';
import bird2 from '../../images/bird2.svg';
import bird3 from '../../images/bird3.svg';
import './addproject.css';

export const AddProject = () => {
    const navigate = useNavigate();
    const {
        projectTitle,
        startDate,
        endDate,
        location,
        description,
        participantQuery,
        participants,
        participantList,
        imageFile,
        imageUrl,
        error,
        handleInputChange,
        handleParticipantSearch,
        handleAddParticipant,
        uploadImage
    } = useProjectInfo();

    const handleAddProject = async (e) => {
        e.preventDefault();
        try {
            await uploadImage();
            const docRef = await addDoc(collection(db, "projects"), {
                projectTitle,
                startDate,
                endDate,
                location,
                description,
                imageUrl,
                participants: participantList
            });
            console.log("Document written with ID: ", docRef.id);
            navigate('/home');
        } catch (error) {
            console.error("Error adding document: ", error);
            // setError("Error adding project. Please try again.");
        }
    };

    return (
        <div class="container-wrapper">
            <img src={bird1} alt="bird" className="bird bird1" />
            <img src={bird2} alt="bird" className="bird bird2" />
            <img src={bird3} alt="bird" className="bird bird3" />
            <div className="container2">
                <img src={logo} alt="Logo" className="logo2" />
                <form onSubmit={handleAddProject}>
                    <div>
                        <label>Project Title:</label>
                        <input type="text" name="projectTitle" value={projectTitle} onChange={handleInputChange} required />
                    </div>
                    <div>
                        <label>Location:</label>
                        <input type="text" name="location" value={location} onChange={handleInputChange} required />
                    </div>
                    <div>
                        <label>Start Date:</label>
                        <input type="date" name="startDate" value={startDate} onChange={handleInputChange} required />
                    </div>
                    <div>
                        <label>End Date:</label>
                        <input type="date" name="endDate" value={endDate} onChange={handleInputChange} required />
                    </div>
                    <div>
                        <label>Description:</label>
                        <textarea name="description" value={description} onChange={handleInputChange} required></textarea>
                    </div>
                    <div>
                        <label>Project Image:</label>
                        <input type="file" name="image" onChange={handleInputChange} />
                    </div>
                    <div className="participant-search">
                        <label>Add Participant:</label>
                        <input type="text" name="participantQuery" value={participantQuery} onChange={handleInputChange} />
                        <button type="button" className="search-button" onClick={handleParticipantSearch}>Search</button>
                    </div>
                    {participants.length > 0 && (
                        <ul className="participant-search-results">
                            {participants.map(participant => (
                                <li key={participant.id}>
                                    {participant.name} ({participant.id})
                                    <button type="button" className="add-participant-button" onClick={() => handleAddParticipant(participant)}>Add</button>
                                </li>
                            ))}
                        </ul>
                    )}

                    {error && <p className="error">{error}</p>}
                    <button type="submit" className="save-button">Save</button>
                </form>
            </div>
            <div className="container3">
                <div>
                    <label>Participant List:</label>
                    <ul className="participant-list">
                        {participantList.map(id => (
                            <li key={id}>{id}</li>
                        ))}
                    </ul>
                </div>
            </div>
        </div>
    );
};

export default AddProject;
